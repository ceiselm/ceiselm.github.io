/**
 * Created by Yusef.
 */

/**
 A Very Simple Textured Plane using native WebGL. 

 Notice that it is possible to only use twgl for math. 

 Also, due to security restrictions the image was encoded as a Base64 string. 
 It is very simple to use something like this (http://dataurl.net/#dataurlmaker) to create one
 then its as simple as 
     var image = new Image()
     image.src = <base64string>


 **/

var grobjects = grobjects || [];


(function() {
    "use strict";

    var vertexSource = ""+
        "precision highp float;" +
        "attribute vec3 aPosition;" +
        "attribute vec2 aTexCoord;" +
        "varying vec2 vTexCoord;" +
        "uniform mat4 pMatrix;" +
        "uniform mat4 vMatrix;" +
        "uniform mat4 mMatrix;" +
        "void main(void) {" +
        "  gl_Position = pMatrix * vMatrix * mMatrix * vec4(aPosition, 1.0);" +
        "  vTexCoord = aTexCoord;" +
        "}";

    var fragmentSource = "" +
        "precision highp float;" +
        "varying vec2 vTexCoord;" +
        "uniform sampler2D uTexture;" +
        "void main(void) {" +
        "  gl_FragColor = texture2D(uTexture, vTexCoord);" +
        "}";


    var vertices = new Float32Array([
         0.5,  -0.5,  -5.0,
        -0.5,  -0.5,  -5.0,
        -0.5, -1.5,  -5.0,

         0.5,  -0.5,  -5.0,
        -0.5, -1.5,  -5.0,
         0.5, -1.5,  -5.0

    ]);

    var uvs = new Float32Array([
       1.0, 1.0,
       0.0, 1.0,
       0.0, 0.0,

       1.0, 1.0,
       0.0, 0.0,
       1.0, 0.0
    ]);

    //useful util function to simplify shader creation. type is either gl.VERTEX_SHADER or gl.FRAGMENT_SHADER
    var createGLShader = function (gl, type, src) {
        var shader = gl.createShader(type)
        gl.shaderSource(shader, src);
        gl.compileShader(shader);
        if(!gl.getShaderParameter(shader, gl.COMPILE_STATUS)){
            console.log("warning: shader failed to compile!")
            console.log(gl.getShaderInfoLog(shader));
            return null;
        }

        return shader;
    }

    //see above comment on how this works. 
    var image = new Image();
    image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAZdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuMjHxIGmVAAAdYUlEQVR4Xu2dB5hU1dnHY2wxahI0asqniebTaGKinyiKIqCoCCpRbNhCEBQIiqhRidLLAkuR3paySAcpS5WlF6V3pMPSls6ytN1li+eb93rQLf/ZnZ2ZO7ec/5/n9zw8/53bztxz595z3/O+P/nJZ/coQoihQJMQYgbQJISYATQJIWYATUKIGUCTEGIG0CSEmAE0CSFmAE1CiBlAkxBiBtAkhJgBNAkhZgBNQogZQJMQYgbQJISYATQJIWYATUKIGUCTEGIG0CSEmAE0CSFmAE1CiBlAkxBiBtB0iIs+Kwt9QohNQNMhqgxpAH1CiE1A0yF6Lx2jft+pKvwbIcQGoOkQnRYlqkGrJsG/EUJsAJoO0XRWT5Wbl6v+3vMl+HdCSJSBpkM0TOqgRItS1qiLmnFAkBDbgaZDvDbuM+sCIKo7sQ38DCEkikDTIZ4Z3kR3f6VOZp5WN8ZXg58jhEQJaDpE5UFv6+7/vebsXK5+2uxe+FlCSBSApkOU6/uG7vo/qtnsPvCzhJAoAE2H+GuPF3S3/1E5ebnqycRG8POEkAiBpkP8scvTutsXVFrGKXV795pwGUJIBEDTIW7o8Lju8kW1O+2A+k3g72g5QkiYQNMhftm2ou7uWOsObVPXtKsMlyWEhAE0HeJnLcur7777Tnd3rOX7N6ky7SrB5QkhpQSaDnFZi/tVdm6O7urBtTp1i7o+rgpcByGkFEDTIS5pXk5l5GTpbl68th3bq27p+gxcDyEkRKDpEBc3v1edOX9Od/GSdfRsmqowsC5cFyEkBKDpEDIBKD3zjO7eoSkr97yqP7m9ugisjxBSAtB0kOPn0nXXDl3fBf4NXztNXd2mAlwnISQI0HSQ1NNHdbcuvXYc36fK968N10sIAUDTQXanperuHJ4koYhkFvp5qwfh+gkh+YCmg2w5mqK7cmTadWK/qpb4DtwGIUQDTQeRaL9oScYGkrYsULd1exZuixDjgaaDSKRftCXBRb2WjuFcAkIKA00HWbxnre620dfZ7AxrfOD6uMfgtgkxDmg6yNxdK3R3tU/nsjNVj29Gq5u7PA33gRBjgKaDzNz+te6m9kveGIzbmKwqDHyTZcmImUDTQWTQzgmtP7RdNUhqr8q05UxDYhDQdJDxG2frLumMMnOy1PC101WVwfXVxUxISvwONB1k5LqZuis6r/3ph1X8omHqnt6vcq4B8SfQdJAhq5N093OXth7bo9rOT1D39OHFgPgIaDpI3+XjdJdzr1LSUlXXJcNVpUFvqctalIPHQYgngKaDdFsyQnczb+hkxmk1Yt10VWtMU3Vt+0fhMRHiWqDpIO0XDNZdy3uS14pL9qxTnyb3Vnf3rsVBROJ+oOkgzef01d3J+5KpzQNXTlQ1Rryvrmz9EDxeQhwFmg7y0czuuvv4SxnZWWrq1kXqzYmt1XVMaErcAjQd5J2pnXSX8a/kUWHerhWqYVKc+m3HJ2A7EBIToOkg9Sa10d3EDOXm5ankHctUnQmt1K/aVoRtQohtQNNBXh37me4a5kmiECUQ6vGhDa0Myah9CIkq0HSQGsPf193BbKWcTFWfJfdhDgNiL9B0kEcH19ddgBKdz81Wo9bPVPf1fR22FyERAU0HKdfvn/rUpwprYcpqVW3Yu5y6TKIHNB3kju7P69OdCiapjfj0F+/xQkAiB5oO8ruOT+jTnCpJS/dtsJKZoHYkJCSg6SCSz58KXVJOXbIa3RhfDbYnIcUCTQf5abOyKisnW5/eVKiSoqrvTescaD++PiSlAJoOInPtj5xN06c1VVot2bOWZdNJ6EDTYTYf3a1PZyocnco6Y01PRm1LSAGg6TCLUtboU5kKV1IVqcuS4YwoJMUDTYeZ+O08fRpTkSpp8wIWSiXBgabDDFgxQZ++VDQkAUS/aPMwbGtiONB0mNZzB+hTl4qW5CLAOwFSBGg6TIOkOH3aUtGUPA4wTRkpADQd5tkRH+hTloq2pDgqanMSHSQO4y89XoB/cyXQdBiZ+UbZo7zv8tRTwxrDdieR8YfOT6nkHUvVnT1fhH93JdB0GJkDT9mng6ePqWvaVYZtT0rPJc3vU42nxqvTWefU5M3zvVU4BpoOI7dRWTnn9elK2aGElZNg25PSUXVoI6uw7AVVTKgLP+daoOkCth/fq5uUskOSmFRqF6C2JyVTKaGemr1zmW7N77Xh0A7vTdGGpgv4avs3ulkpuyRvBVDbE8ylLcqpF0Z9pBbvWatbsKDendoJLudqoOkCei8dq5uVsksylfgv3Z+H7U9+5LZuz1qFYaVadDBlBh5ZPTmuAk0XIFNbKfvVe+kY2P4mI7fxf/68pvr4qx5qVepm60JZkmTwD63L9UDTBVQf9q5uWspOHTt7Ul3anBWO5ddb4k96BS6IO0/s160Tul4d+ylcr+uBpgu4pcszquTrLhUNPZn4DvwO/Iq8Zbqje01V+8sWqu+ycdYovsRHhCsp+3aVV2s/QtMFyLvVc9mZuokpO9Xzm9HwO/ADkmFKAnRqjvyPilsw2ArUSc88rY88OpIBa7RtTwBNlyBJLyn7teHwDtj+XkRu5R8f0lA1m91HTd2yUB07d1IfpX16Z0pHuC+eAJouIWHlRN3ElJ3KyctRV7euAL8Dt1Mm37O7XMgiuZUPV7d2exbumyeApktoFLiyUrHRQwPqwO/AbUiY7c1dnlYfzuhmTXHOycvVR+CM9pw86K3Q38JA0yU80L+2bmbKbklVZvQduAVJaFJ/cjvrsTCU13Kx0rA1U+H+egZouoQrWz2osnNzdFNTdkoCXdB34DR/6lrDur0/cz5D76m7VH9ye7jfngGaLmLFgU26qSk7NWR1Emx/p5DXwENXT1G5DjzTl0Z/6/kS3H/PAE0X0W3JCN3UlJ1ySySbDEZK0hKpiux2nT2f6f0MS9B0ETVHfqib272SeAWpZeDECHS0NHfXCtj+sUIG0h4f2lDtPXlQ75H7JeMR6Fg8BTRdxHXtH1W5ee7vWMfPpauuS4ar9vMHB07iQ9r1jhbvWQPbPxZc1uJ+607PTYN7oajf8i/h8XgKaLqMtQe36SZ3vzYe3qmqDGmgngvcuch8ca+c1F/vXQfb3m4k+5OUM/Oi3p0aD4/JU0DTZXRYOEQ3uTckVXlkUO3XgbsXGSRKXDPV9c+0C1JWw7a3kzu6P69S0lL1HnhPVRMbwePyFNB0GRUT6ukm95YOnzlu3QnI8+1N8dVVn2VjrYkjbtTMbV/DtreLe/q8GpMwXTt1U+fq8Ng8BTRdhkwMOpGRrpvdW5K7AQkW+WWbitax/L5TVdV3+XjX3RGM2TCrSLvbxd29aqm0jFN6y96U5Ky8NHBeouPzFNB0IdKJvKxdJ/arcv3e+OF4JJx15LoZrnlzINNi87e3XUhgj9wZeV3y6IKOz3NA04XUGN5EN713Jb/6jafFF4gdL9vnNTV/9yr9CefUYk6/Au1tB2XaVVJbj6boLXpbSxwaNI060HQhl7d8IHDbGN153E5p5PqZVpjzhWOTC4Ikm9yddkB/IvaqO7F1gfaONhIwM33bEr017+vLTXPgcXoOaLqUgT6aHrzm4BZrYDD/8V3RsrwVk5+ZE/uBwseGNCiwL9FG5uf7Sf39EAMgQNOlPDSwjm5+f0gq9MgjQOHjvLXbP6zIvFjqxvhqRfYjWpTvX9vxabvRVtyCIfBYPQc0XcpFzcqqrcf88Qx5QWfOn7MSoBY51s/KqjoTWsbk7ceZrHNWnrzC+xANpCS5H4u8NJ3VEx6v54Cmi2niw3Th8usoCSrR8f624xNWAQ87tSZ1K9x2NOi0MFFvxV96x4tFQBDQdDGS8+2sS+eGRyJ5HVhcZZk3xjezbRBUIhXRNiNFquRKujE/yu0JVEIGmi5Hstj6URI09N/kXvCYBRk0tGNsQIqwoO1FgjzCzNm5XG/Bf/pnkDs2zwFNlyNBNH79ZREVdxGQZ/Wms3pFNVNS+f7/gtuKhGo+L+zy+rhm8Lg9BzQ9gGSL8atk/qCUpULHfYH7+/1T7Y7CRBqpaXd5i/vhNiLhm73r9Rb8qTfGN4fH7Tmg6QEkpDTbx3cBMo24YVIcPPYLSGRdpAOEK/ZvguuOhHv7vq7X7l/VmdAKHrvngKZHkEk1fpYkQnll7H/hsV9AKt/II4HU+w9HksQErTcSJImn3/XWpLbw2D0HND3CDXGPqVNZZ/VX4k/J/IEnhv4bHn9+pBpOONNrnxneBK4vXGSMQgKc/C6pWYGO33NA00NIgQi/Sy5yd/V6GR5/fm7p+oxVHSdUyR3Gr9pWgusKF5nnb4Len94VHr/ngKaHuKxFOSsNl9+1P/2w+p9OT8I2yI9k1Z2+dbFeqnitPBD95///zPxcr93f+mhmd3j8ngOaHkNeY3k5I2+oWnVgs7qiVXnYBvmRBCqSfagk2VEMZNLm+Xrt/tYnDAV2F50XD9Nfjb81av1MK8gGtUF+ZIqx3KYWd2F8cEB03//LXA0Tnv9FMvCK2sBzQNOD/KxlebX+0Hb99fhbpZmIUmtMUyt9VWGdOJdu3SmgZcLl2vaPeC61d7gqKU7DM0DTo9zevaY1u87vkslDVQbXh22AkDcEpwu9LRm9/iv42UiQCsOm6MOZn8M28BzQ9DAvjf7EiF+hI2dOhDQoeAGptJw/EefLgTsD9LlIkPh4U9RkehfYBp4Dmh5HkjWYoCV715bqNl5e0R0/d1JlZmdZbwvQZyKh+Zy+es/8r5KiND0DND2ORMeN3Zisvyp/q938QbANgiEXARlIRH+LFMksbIpqf9kStoHngKYP+FnLB3w9HfWCJJjn0VKMBwjRHvy7gCTKdEIyjXruruVRmRwVquRRE7WB54CmT5Db3MUerTtXGu0/ddhKlILaIJYsTFmt9yh2klmHFRPqxnz+gS/KggnQ9BFXt6ngyIkZa0lln/z1Bpxg3aHYFXFNOZmqXhz9sRUTITUNYi2Zjo3awHNA02dI9NzUrYv0V+dfvTr2U3j8sSIlBrX9Jaah7bwEK4W6bLNBUnv9l9hK5l0UPn5PAk0fIs+9fp8+LME9Um4bHX8sOGFzvb/FKWusisIXtvf8qI9UrgMh4BJdeVXrhwocu2eBpk+RW2SZxun2Ut2RaNLmeY49CtiVrFWCuxpP61wgdbkMfKIIx1jotI1p1GMONH2OxMDvicHtqlMqKYmIHcir14zsTL0H0dPSfRvUrd2eLbAtKaZSOLIxltpxfF+B/fE00DSAMu0qWwNn8grJb5IowWvbPQKP2y6k9l9GFEuaSbhzm3kD1SXNCr6ylIvBkbMn9KecUfKOpQX2ydNA0yBeGPWxL2ewDVmdBI/XLmQm4Lko3QEcOHVEVR70dpFt3NDhMbXzxH79KefUf4VP6gIK0DQMyYojUWx+ql8n8yEqD3oLHq9dRGMiltQ9kI5eeN0y6LbiwCb9KWf1wQyfZAMSoGkof+v5kpq5bYlvHgu+PbJLXdq8HDxWO8g/2ai0ygtcsDouHGo9ShRerxzDDBeVFg8lR6NngKbhSGRZ8o5lvsgy9EkM563vSz+st1o6yZ2DBPWgdUqgj5vKwsuF6rq4KnBfPQk0iYXUHpAqPRJJGK3n22hLKiQdPZumMrLxAJx0rtJMG44EueMoreRtzN29a8H1CZJ5x01KSUt1POIyqkCTFOGyFvdbBS/qTmyjOi/+Qk34dq5avn+j9asnnS/cvPz5JWMQmTlZVkDP7rQDanXqFjV75zLrbUWfZeNUy7n9VYPJ7dVzIz608iDe1Lm6urzlA9YJ+cKoj4I+uoyyIfkHYtm+jXqLoUle8aHn/QtINiO35XaQ7wLtq2eBJikVFze/V13Z+iErCk8i1eRCUTGhnpWJ58nEd1T1YY3VU180Dvy/kXos4D0y6G318MC6qmzf19Ttn9e0fqHltaTU0pd1oW2UhFwEgs3Gk05UYeCbcLloMmvHUr3FkjVuY/IP4byI8v1rW2XL3CYJPUb761mgSTzJjfHVgkbjSUZhCdZBy0UL+XUMRZLAtbh9keM45NJXs7d08ckcgAtAk3iWT5ODPzPXtrmkdb8S5lrIY1LjafFw2QvInZQ8+rhRMsbhq+d/AZrEs0h2ZBmoQtqXfijwmFFyXYFwaT1voN5SUUnc/ktjik+iIXcF4zfO1ku4TxKZiPbb00CTeBpJ+BlMzWb3gctEA5lohSRx+48NaQCXyY+8snSrZIA1/0xE3wBN4mkkLFfeUCClZ55Rv27/KFwuUp4f9R+9lR91/Fy6ur/fG/Dz+ZHBUUlv5lYt2bMW7rfngSbxPBIGHOy1YPevR8JlIqVcoKPnlwzk3dnzRfjZ/NwUXz2sysaxVEmPL54FmsQXBMuCJK/X/tj5KbhMJPyuY1W9he+Lmf758+fg5/Ij8RWS18/N2nZsr22JVB0HmsQX/C3w6xssY07imilwmUiQSs0y2CeDkLd0qQE/Uxgv1HSsNSb2+RViBjSJb5COjiRRh1JKDS0TCck7l1m39Ohvhak6tJHrqzgt2bPO9vgJR4Em8Q03d3lanc/BKdAkGg8tEwmXB27pkV+Y69o/6vo8DPKodGePkscwPA00ia/o8c0ofUoXlMxsu6vXy3AZO5EZfhM2zdV74V59OKMb3H9fAU3iK2TCTbBkHTKpCS1jJ5K+3O0av2mOdaFC++8roEl8R7CCqZLzoLjpuNHmhg6PW7Md3ayv9663Jmah/fcd0CS+Q4J/gt0FTPx2HlzGDkKdMOSUlu3faKWIQ/vuS6BJfImk3EKSV4WSDg0tE02qJb4T2Jp7R/2nb1vsn4IfoQJN4kskUCdYUZSxG6L/RiA/Uq1554l9emvuksxSlDLrKB+h74Em8S1DViXp076gJC4glMi9cPk0ubfekru0/fheVSmhHtxnI4Am8S13Bm71gwXfJK6OfnSgIHcedpUNC1cnM09buRPkzgTtszFAk/iaOTuX625QUPJ48Acb5ggMXjVZb8F5HTp9XLWaO0Bd064y3FfjgCbxNf8Y8YHuDkXVe+lYuEy4/LXHi45P883OzVFfbf/Gij+Q+QpoP40FmsTXyMy2YMVRJf35dXHRyxcw6dv5es2xleQhkGjDOhNa+SuPf7SBJvE9xQ3KSWovtExpuafPqzGZ7CMXLckjmLBykmqQFGe90jRyRD8coEl8jwzMya0xkiTnkOScaLnSMHlzZL/+EqV4KuuMlctw7cFt1m380NVTVNyCwertye2sEl2Spdc3tfqdAJrECCQCMJjem9YZLhMq8isc7Nd/zcGtqmqg81ZKeEs9nFBXPTigjrqv7+vq771etl5F/r7Tk+oXbR62OrYR8fhOAk1iBNWGvau7ZFFJUo9IsuB8sXaaXlNBybO53H2gZYgDQJMYgTwnSy3+YHp9XDO4XEnIL3iwx4sm07vAZYhDQJMYQ4cgswRFMrAWzi14+8AzOtKxs2lW3QK0DHEIaBJjkNqEwSRP8FLHEC0XDImsk2rFSPGLEuEyxEGgSYxi2b4NuosW1fSti+EywZDHBiRJUS4XG7QMcRBoEqNoNKWD7qZFJVOF7wgxeajUzVu8Z41esqBWpW6GyxCHgSYxComUCzZoJ0pYOREuV5g/B37hg736++SrnnAZ4jDQJMaRtGWB7qpFlZGdpa4PIZw22OCf3P7bOdWYRAA0iXFI8Yvi1HJuf7jcBS5ufp9VDQhp27E9cBniAqBJjOOq1hWKnbN/+MxxdXkxc+crJtTTnywqu2oRkigATWIkI9bN0F0W680JreByQr/l4/WniuqJoY3gMsQFQJMYyTPDm+gui7Xu0DZrpL/wcpc2Lxf03b/M1GPwj4uBJjESCeJJzzyjuy5WlcENiiz3yOC39V+LSrIPFf48cRHQJMYieQGLk5QcL7xMz29G678WVdNZvYp8nrgIaBJjeWpYY911sSSF9m3dnv3h8xc1K6v2njyk/1pU5fq9UWD9xGVAkxjL5S1Kfgzou2zcD5+/q1ct7RZVWsZpdXGz8KcUkxgATWI0I9ZN110YS0qMlWn3ffms/wZu8YNpypaFRdZNXAY0idE8N/JD3YWDq+ms70N7F6Xg2H/R+9O7Flk3cRnQJEYjlXFLKuSxL/2wurbdIyo7L/gcAknxhdZPXAQ0ifGM25isu3Fwjdnwlf5fUR05e8IaIETrJi4CmsR4SpobUJLGb5wN10tcBjSJ8UiN/OKmCJekhkkd4HqJy4AmIQEkD3+44vRfjwBNQgLIr3g4kkIeaM4AcSHQJCTAjfHVwirtJdWA0fqIC4EmIZrVqZt1tw5dL47+GK6LuBBoEqJpOae/7tah6Xxutvplm4pwXcSFQJMQTdk+r+muHZqSdyyD6yEuBZqEaKR82MHTx3T3LllvTWoL10NcCjQJycfAlRN19y5eGdmZqky7ynAdxKVAk5B8SJnuawId+5auNdS9fV9Tjw9pqF4a/YlVo18mBXValKgGrpioPvmqB1yeuBhoEkLMAJqEEDOAJiHEDKBJCDEDaBJCzACahBAzgCYhxAygSYxHyn1d2foh9ZsOj6vbPn9O/V/vV1T5Af9Sjw6ur6omNlLVh71rlRJ7+ov3VLXA/58Y+m9VedBb6oH+tdVdvV5Wf+paQ10XV0Vd0epBdUlzpgZ3LdAkvkXm6UvSz7/0eMHqxP+e0kHFLRiiEtdMVck7lqoNh3dYdf4yc7LCmgpcWHnf5Vn1AVNPH1WrU7eoaVsXW5GFreYOUHUntlFVhjSwLhaXtbgf7i+xGWgSX3B1mwrqoQF1VP3J7azyXbN3Lrdq+OcGOqXbJLMIdxzfp6ZuWaQ6LkxUb4xvbt118MJgM9AknkMKe0oZrsbT4tXIdTPUlqMp1q+v1yUXhlWpm9WAFROs8uRy53Jx83thG5AwgCZxPdLhKybUC9xK91dzd62wbtlNUVrGKTV583z1wYxu6u7etXhBiARoEtchz+43d3lGNZrSUU0PPEfLczX1vY6dTbPuel4b95k18IjajwQBmsQV/LRZ2cAv3CuqzbyB6tsju6IyKOd3SfXixXvWqCbTu6g/dn4KtivJBzSJo9zevaZqHej024/v1ac1FY7yAhfMZfs2WOMi8joTtbXxQJPEHEmkIWm4l+3bqE9fKprKyctR07YuUi+M/lhdzjcLPwJNEhPkuV4CZ4auTrKy6VCxkdQt7LhwqPrfrjXg92IU0CS2Ir9Ar437VK3Yv0mfkpQTktekSZsXqCqD61vjLei78j3QJLYggTlSM19Ka1PukkQpvjymqXlhy9AkUeUXbR5Wnyb3VsfPndSnG+VWycBr7S9bmHMhgCaJChJz/9HM7oGOn65PL8or2n5sr6oVuCOQhKjou/UN0CQRcUngpKkzoZU6cOqIPp0or2rNwS2qyuAG/i12Ck0SNpUS6qm1B7fq04fyi6ZsWahu7fYP+J17GmiSUvPbjk+oEetmqO8C/yh/KivnvBWV+fNW5eE54EmgSUJGXh/Vm9RWncw4rU8Tyu+SacuSGAWdD54DmiQk/tD5KTVn53J9WlAmSeZlyBRlecODzg3PAE1SLDIgJIN8p7LO6tOBMlW70w6ohwfWheeJJ4AmCUqZtpXUmA2z9NdPUd/PQJQUZ56MHYAmgdzT+xW188R+/bVTVEHN373Se7MOoUmKINFhJmXdocLTwdNHrezJ6BxyJdAkPyC3dd2+HsGXe1TIkteFdSa0hOeT64AmsbiqdQUrAISiSiuJB2k/f5D7ZxlCk6jr46qolQe+1V8nRYWn4Wunq0tblIPnmCuApuHcFF/dSqtNUdGQZCKSiWHoXHMcaBqMJJKUd7sUFU3N3blcXenGiwA0DUUi+1JOpuqvjKKiq3m7VqgrWrpsHgE0DUTe3zILL2W3pDbiZW4aE4CmgciI/+86ViXEdlyVlRiahBAzgCYhxAygSQgxA2gSQswAmoQQM4AmIcQMoEkIMQNoEkLMAJqEEDOAJiHEDKBJCDEDaBJCzACahBAzgCYhxAygSQgxA2gSQswAmoQQM4AmIcQMoEkIMQNoEkLMAJqEEDOAJiHEDKBJCDEDaBJCzACahBADuEf9PzhoS5caASIDAAAAAElFTkSuQmCC"
    //useful util function to return a glProgram from just vertex and fragment shader source.
    var createGLProgram = function (gl, vSrc, fSrc) {
        var program = gl.createProgram();
        var vShader = createGLShader(gl, gl.VERTEX_SHADER, vSrc);
        var fShader = createGLShader(gl, gl.FRAGMENT_SHADER, fSrc);
        gl.attachShader(program, vShader);
        gl.attachShader(program, fShader);
        gl.linkProgram(program);

        if(!gl.getProgramParameter(program, gl.LINK_STATUS)){
            console.log("warning: program failed to link");
            return null;

        }
        return program;
    }

    //creates a gl buffer and unbinds it when done. 
    var createGLBuffer = function (gl, data, usage) {
        var buffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
        gl.bufferData(gl.ARRAY_BUFFER, data, usage);
        gl.bindBuffer(gl.ARRAY_BUFFER, null);
        return buffer;
    }

    var findAttribLocations = function (gl, program, attributes) {
        var out = {};
        for(var i = 0; i < attributes.length;i++){
            var attrib = attributes[i];
            out[attrib] = gl.getAttribLocation(program, attrib);
        }
        return out;
    }

    var findUniformLocations = function (gl, program, uniforms) {
        var out = {};
        for(var i = 0; i < uniforms.length;i++){
            var uniform = uniforms[i];
            out[uniform] = gl.getUniformLocation(program, uniform);
        }
        return out;
    }

    var enableLocations = function (gl, attributes) {
        for(var key in attributes){
            var location = attributes[key];
            gl.enableVertexAttribArray(location);
        }
    }

    //always a good idea to clean up your attrib location bindings when done. You wont regret it later. 
    var disableLocations = function (gl, attributes) {
        for(var key in attributes){
            var location = attributes[key];
            gl.disableVertexAttribArray(location);
        }
    }

    //creates a gl texture from an image object. Sometiems the image is upside down so flipY is passed to optionally flip the data.
    //it's mostly going to be a try it once, flip if you need to. 
    var createGLTexture = function (gl, image, flipY) {
        var texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, texture);
        if(flipY){
            gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        }
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,  gl.LINEAR);
        gl.generateMipmap(gl.TEXTURE_2D);
        gl.bindTexture(gl.TEXTURE_2D, null);
        return texture;
    }

     var TexturedPlane = function () {
        this.name = "TexturedPlane"
        this.position = new Float32Array([0, 0, 0]);
        this.scale = new Float32Array([1, 1]);
        this.program = null;
        this.attributes = null;
        this.uniforms = null;
        this.buffers = [null, null]
        this.texture = null;
    }

    TexturedPlane.prototype.init = function (drawingState) {
        var gl = drawingState.gl;

        this.program = createGLProgram(gl, vertexSource, fragmentSource);
        this.attributes = findAttribLocations(gl, this.program, ["aPosition", "aTexCoord"]);
        this.uniforms = findUniformLocations(gl, this.program, ["pMatrix", "vMatrix", "mMatrix", "uTexture"]);

        this.texture = createGLTexture(gl, image, true);

        this.buffers[0] = createGLBuffer(gl, vertices, gl.STATIC_DRAW);
        this.buffers[1] = createGLBuffer(gl, uvs, gl.STATIC_DRAW);
    }

    TexturedPlane.prototype.center = function () {
        return this.position;
    }

    TexturedPlane.prototype.draw = function (drawingState) {
        var gl = drawingState.gl;

        gl.useProgram(this.program);
        gl.disable(gl.CULL_FACE);

        var modelM = twgl.m4.scaling([this.scale[0],this.scale[1], 1]);
        twgl.m4.setTranslation(modelM,this.position, modelM);

        gl.uniformMatrix4fv(this.uniforms.pMatrix, gl.FALSE, drawingState.proj);
        gl.uniformMatrix4fv(this.uniforms.vMatrix, gl.FALSE, drawingState.view);
        gl.uniformMatrix4fv(this.uniforms.mMatrix, gl.FALSE, modelM);

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.uniform1i(this.uniforms.uTexture, 0);



        enableLocations(gl, this.attributes)

        gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[0]);
        gl.vertexAttribPointer(this.attributes.aPosition, 3, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[1]);
        gl.vertexAttribPointer(this.attributes.aTexCoord, 2, gl.FLOAT, false, 0, 0);

        

        gl.drawArrays(gl.TRIANGLES, 0, 6);

        disableLocations(gl, this.attributes);
    }


    var test = new TexturedPlane();
        test.position[1] = 3;
        test.scale = [2, 2];

    grobjects.push(test);

})();